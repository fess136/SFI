from django.contrib import admin
from apl.models import*
# Register your models here.
admin.site.register(Tipo)
admin.site.register(Administradores)
admin.site.register(Tipo_identificador)
admin.site.register(Clientes)
admin.site.register(Presentacion)
admin.site.register(Marcas)
admin.site.register(Unidad_Medida)
admin.site.register(Proveedores)
admin.site.register(Empleados)
admin.site.register(Productos)
admin.site.register(Compras)
admin.site.register(Metodo_Pago)
admin.site.register(Ventas)


