-- MySQL dump 10.13  Distrib 8.0.39, for Win64 (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `conf_contrasena` varchar(128) NOT NULL,
  `contrasena` varchar(128) NOT NULL,
  `numero_documento` int unsigned NOT NULL,
  `telefono` int unsigned NOT NULL,
  `tipo_documento` varchar(3) NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_documento` (`numero_documento`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `Administrador_user_id_949907f5_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `administrador_chk_1` CHECK ((`numero_documento` >= 0)),
  CONSTRAINT `administrador_chk_2` CHECK ((`telefono` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
INSERT INTO `administrador` VALUES (1,'Herbert','password123','password123',471117157,19883939,'CE',2),(2,'Thomas','password123','password123',987765069,11542203,'CE',3),(3,'Laura','password123','password123',171261351,99960635,'CC',4),(4,'Daniel','password123','password123',52007110,98202306,'CC',5),(5,'Michael','password123','password123',485145894,61370193,'CC',6);
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apl_detallecompra`
--

DROP TABLE IF EXISTS `apl_detallecompra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apl_detallecompra` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `producto_id` bigint NOT NULL,
  `compra_id` bigint NOT NULL,
  `cantidad` int unsigned DEFAULT NULL,
  `precio_unitario` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `apl_detallecompra_producto_id_96576587_fk_Producto_id` (`producto_id`),
  KEY `apl_detallecompra_compra_id_3a0209a2_fk_Compra_id` (`compra_id`),
  CONSTRAINT `apl_detallecompra_compra_id_3a0209a2_fk_Compra_id` FOREIGN KEY (`compra_id`) REFERENCES `compra` (`id`),
  CONSTRAINT `apl_detallecompra_producto_id_96576587_fk_Producto_id` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`),
  CONSTRAINT `apl_detallecompra_chk_1` CHECK ((`cantidad` >= 0)),
  CONSTRAINT `apl_detallecompra_chk_2` CHECK ((`precio_unitario` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apl_detallecompra`
--

LOCK TABLES `apl_detallecompra` WRITE;
/*!40000 ALTER TABLE `apl_detallecompra` DISABLE KEYS */;
INSERT INTO `apl_detallecompra` VALUES (1,91,7,46,475),(2,376,3,47,350),(3,140,9,22,674),(4,394,4,46,984),(5,44,7,42,533),(6,65,3,52,544),(7,421,8,99,208),(8,66,1,8,984),(9,496,5,54,385),(10,374,10,70,247),(11,61,9,80,613),(12,459,6,94,989),(13,221,9,7,212),(14,57,8,77,688),(15,67,10,18,877),(16,408,5,28,214),(17,119,4,52,666),(18,385,3,79,243),(19,465,3,2,588),(20,168,6,8,611),(21,3,6,26,326),(22,209,3,42,357),(23,415,6,100,697),(24,159,1,66,401),(25,99,5,48,60),(26,87,2,99,196),(27,11,6,86,846),(28,4,10,50,138),(29,454,4,66,619),(30,134,6,8,267),(31,454,6,28,283),(32,199,2,83,338),(33,58,1,84,414),(34,191,6,39,607),(35,67,5,84,420),(36,486,4,45,108),(37,369,10,20,570),(38,114,3,3,550),(39,432,5,52,735),(40,260,7,43,295),(41,70,8,58,140),(42,288,1,48,192),(43,168,1,86,226),(44,226,3,56,38),(45,259,2,3,880),(46,365,8,59,523),(47,300,8,95,116),(48,91,8,48,319),(49,153,6,13,71),(50,391,4,99,202);
/*!40000 ALTER TABLE `apl_detallecompra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apl_detalleventa`
--

DROP TABLE IF EXISTS `apl_detalleventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apl_detalleventa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int unsigned NOT NULL,
  `producto_id` bigint NOT NULL,
  `venta_id` bigint NOT NULL,
  `precio_unitario` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `apl_detalleventa_producto_id_f3556a55_fk_Producto_id` (`producto_id`),
  KEY `apl_detalleventa_venta_id_3bab7eea_fk_Venta_id` (`venta_id`),
  CONSTRAINT `apl_detalleventa_producto_id_f3556a55_fk_Producto_id` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`),
  CONSTRAINT `apl_detalleventa_venta_id_3bab7eea_fk_Venta_id` FOREIGN KEY (`venta_id`) REFERENCES `venta` (`id`),
  CONSTRAINT `apl_detalleventa_chk_1` CHECK ((`cantidad` >= 0)),
  CONSTRAINT `apl_detalleventa_chk_2` CHECK ((`precio_unitario` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apl_detalleventa`
--

LOCK TABLES `apl_detalleventa` WRITE;
/*!40000 ALTER TABLE `apl_detalleventa` DISABLE KEYS */;
INSERT INTO `apl_detalleventa` VALUES (1,86,276,5,886),(2,65,50,6,308),(3,89,295,1,270),(4,69,458,10,657),(5,28,191,4,806),(6,47,215,10,928),(7,12,54,9,109),(8,50,372,7,118),(9,78,145,6,771),(10,12,219,1,378),(11,67,273,7,435),(12,96,439,8,655),(13,72,159,5,795),(14,9,294,8,529),(15,8,398,2,169),(16,49,163,10,981),(17,14,206,7,489),(18,96,81,5,899),(19,1,23,6,785),(20,78,159,4,810),(21,69,119,9,692),(22,91,109,2,983),(23,46,444,3,464),(24,58,283,6,992),(25,30,325,7,925),(26,66,162,8,863),(27,95,8,1,872),(28,26,66,3,786),(29,45,50,1,38),(30,61,44,9,661),(31,66,330,5,515),(32,68,431,7,947),(33,66,56,5,56),(34,29,369,10,130),(35,44,318,9,809),(36,25,20,7,359),(37,89,283,3,206),(38,64,70,10,262),(39,97,448,4,176),(40,71,308,6,751),(41,88,23,7,817),(42,100,262,9,721),(43,88,37,9,433),(44,81,154,8,286),(45,90,117,1,324),(46,86,470,9,367),(47,29,194,6,287),(48,19,167,9,291),(49,45,185,8,28),(50,33,407,7,956);
/*!40000 ALTER TABLE `apl_detalleventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add Tipo',7,'add_tipo'),(26,'Can change Tipo',7,'change_tipo'),(27,'Can delete Tipo',7,'delete_tipo'),(28,'Can view Tipo',7,'view_tipo'),(29,'Can add Administrador',8,'add_administradores'),(30,'Can change Administrador',8,'change_administradores'),(31,'Can delete Administrador',8,'delete_administradores'),(32,'Can view Administrador',8,'view_administradores'),(33,'Can add Tipo Identificador',9,'add_tipo_identificador'),(34,'Can change Tipo Identificador',9,'change_tipo_identificador'),(35,'Can delete Tipo Identificador',9,'delete_tipo_identificador'),(36,'Can view Tipo Identificador',9,'view_tipo_identificador'),(37,'Can add Cliente',10,'add_clientes'),(38,'Can change Cliente',10,'change_clientes'),(39,'Can delete Cliente',10,'delete_clientes'),(40,'Can view Cliente',10,'view_clientes'),(41,'Can add Marca',11,'add_marcas'),(42,'Can change Marca',11,'change_marcas'),(43,'Can delete Marca',11,'delete_marcas'),(44,'Can view Marca',11,'view_marcas'),(45,'Can add Presentación',12,'add_presentacion'),(46,'Can change Presentación',12,'change_presentacion'),(47,'Can delete Presentación',12,'delete_presentacion'),(48,'Can view Presentación',12,'view_presentacion'),(49,'Can add Proveedor',13,'add_proveedores'),(50,'Can change Proveedor',13,'change_proveedores'),(51,'Can delete Proveedor',13,'delete_proveedores'),(52,'Can view Proveedor',13,'view_proveedores'),(53,'Can add Unidad de Medida',14,'add_unidad_medida'),(54,'Can change Unidad de Medida',14,'change_unidad_medida'),(55,'Can delete Unidad de Medida',14,'delete_unidad_medida'),(56,'Can view Unidad de Medida',14,'view_unidad_medida'),(57,'Can add Producto',15,'add_productos'),(58,'Can change Producto',15,'change_productos'),(59,'Can delete Producto',15,'delete_productos'),(60,'Can view Producto',15,'view_productos'),(61,'Can add Metodo de pago',16,'add_metodo_pago'),(62,'Can change Metodo de pago',16,'change_metodo_pago'),(63,'Can delete Metodo de pago',16,'delete_metodo_pago'),(64,'Can view Metodo de pago',16,'view_metodo_pago'),(65,'Can add Compra',17,'add_compras'),(66,'Can change Compra',17,'change_compras'),(67,'Can delete Compra',17,'delete_compras'),(68,'Can view Compra',17,'view_compras'),(69,'Can add Venta',18,'add_ventas'),(70,'Can change Venta',18,'change_ventas'),(71,'Can delete Venta',18,'delete_ventas'),(72,'Can view Venta',18,'view_ventas'),(73,'Can add detalle compra',19,'add_detallecompra'),(74,'Can change detalle compra',19,'change_detallecompra'),(75,'Can delete detalle compra',19,'delete_detallecompra'),(76,'Can view detalle compra',19,'view_detallecompra'),(77,'Can add detalle venta',20,'add_detalleventa'),(78,'Can change detalle venta',20,'change_detalleventa'),(79,'Can delete detalle venta',20,'delete_detalleventa'),(80,'Can view detalle venta',20,'view_detalleventa');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$870000$QTRrzMfjVJwyzhph2WJiSE$O6JNeqFVhNCpHIpt13paQYZdyeLmi4s0/AyfBpBpj6k=','2024-10-09 19:35:06.690564',1,'CRIS','','','adsfsadf@gmail.com',1,1,'2024-09-11 20:18:56.937351'),(2,'pbkdf2_sha256$600000$l5rAxb9BUTFyRhHIbEVLwX$fzIr+gFj9ax+eM3YDJTTwsiOL0L4wnE6kTnDd5nGQSc=',NULL,0,'william75','','','',0,1,'2024-09-11 21:33:22.976899'),(3,'pbkdf2_sha256$600000$9R6gYsUiYYHP8iQ1zv0pWf$wH7sYF69GDmr9o26JOxY+VUL9DfaLPVx7VEfgqGs+rQ=',NULL,0,'tracyferrell','','','',0,1,'2024-09-11 21:33:23.271981'),(4,'pbkdf2_sha256$600000$wdRAD4eVljD1tSVqmrHaKR$HO6n0gO9Tk1X+ppQ7HRtbgM87jsvwsn6E2HJ5/Li8C0=',NULL,0,'icarr','','','',0,1,'2024-09-11 21:33:23.563611'),(5,'pbkdf2_sha256$600000$oS9mZNQuCkspUY6tQhhgnV$VpuoZMkwcefALAe9j4IZgIUpFijLXhjfNxqhrQalybA=',NULL,0,'christina10','','','',0,1,'2024-09-11 21:33:23.851812'),(6,'pbkdf2_sha256$600000$X8t121ADgfbliMCR0GJUxI$SbRlqHzhLaapG5psFemJ3oXu54wNCjEeZ9wTZ6MsoMw=',NULL,0,'annajohnson','','','',0,1,'2024-09-11 21:33:24.138845');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `apellido` varchar(150) NOT NULL,
  `nit` bigint unsigned NOT NULL,
  `correo_electronico` varchar(150) NOT NULL,
  `telefono` int unsigned NOT NULL,
  `Tipo_identificador_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nit` (`nit`),
  KEY `Cliente_Tipo_identificador_id_c98f0af8_fk_Tipo_identificador_id` (`Tipo_identificador_id`),
  CONSTRAINT `Cliente_Tipo_identificador_id_c98f0af8_fk_Tipo_identificador_id` FOREIGN KEY (`Tipo_identificador_id`) REFERENCES `tipo_identificador` (`id`),
  CONSTRAINT `cliente_chk_1` CHECK ((`nit` >= 0)),
  CONSTRAINT `cliente_chk_2` CHECK ((`telefono` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Scott','Baldwin',656716206,'andrewmontgomery@example.org',69915571,1),(2,'Richard','Morris',513453154,'millsanna@example.net',2587195,1),(3,'Xavier','Noble',282985734,'maxwellperez@example.net',54142085,1),(4,'Molly','Ryan',709864134,'jenniferhenry@example.net',12102220,1),(5,'Joseph','Porter',221599312,'joshuajohnson@example.com',93004975,1),(6,'Taylor','Pratt',927430830,'jennychang@example.net',92849338,1),(7,'Joseph','West',494979755,'brian63@example.org',80952540,1),(8,'Jessica','Combs',153625499,'nicolejefferson@example.org',86450299,1),(9,'James','Rose',3172308,'mary30@example.com',12882267,1),(10,'Shannon','Walker',646536983,'jessicabush@example.org',66460483,1);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compra` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_compra` date NOT NULL,
  `metodo_pago_id` bigint NOT NULL,
  `proveedor_id` bigint NOT NULL,
  `finalizado` tinyint(1) DEFAULT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Compra_metodo_pago_id_7a20b5a3_fk_Metodo de pago_id` (`metodo_pago_id`),
  KEY `Compra_proveedor_id_b98cf6f8_fk_Proveedores_id` (`proveedor_id`),
  CONSTRAINT `Compra_metodo_pago_id_7a20b5a3_fk_Metodo de pago_id` FOREIGN KEY (`metodo_pago_id`) REFERENCES `metodo de pago` (`id`),
  CONSTRAINT `Compra_proveedor_id_b98cf6f8_fk_Proveedores_id` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
INSERT INTO `compra` VALUES (1,'2024-09-11',5,4,0,'brivera'),(2,'2024-09-11',4,2,1,'burkevalerie'),(3,'2024-09-11',1,2,1,'gsimpson'),(4,'2024-09-11',2,2,0,'awilliams'),(5,'2024-09-11',2,8,0,'monicawalker'),(6,'2024-09-11',5,10,0,'marcus09'),(7,'2024-09-11',5,8,0,'plynn'),(8,'2024-09-11',1,4,1,'jfarrell'),(9,'2024-09-11',2,9,1,'gonzalezluis'),(10,'2024-09-11',2,3,1,'savannah64');
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(8,'apl','administradores'),(10,'apl','clientes'),(17,'apl','compras'),(19,'apl','detallecompra'),(20,'apl','detalleventa'),(11,'apl','marcas'),(16,'apl','metodo_pago'),(12,'apl','presentacion'),(15,'apl','productos'),(13,'apl','proveedores'),(7,'apl','tipo'),(9,'apl','tipo_identificador'),(14,'apl','unidad_medida'),(18,'apl','ventas'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2024-09-11 20:17:40.879607'),(2,'auth','0001_initial','2024-09-11 20:17:41.166588'),(3,'admin','0001_initial','2024-09-11 20:17:41.265751'),(4,'admin','0002_logentry_remove_auto_add','2024-09-11 20:17:41.273834'),(5,'admin','0003_logentry_add_action_flag_choices','2024-09-11 20:17:41.281582'),(6,'apl','0001_initial','2024-09-11 20:17:41.296696'),(7,'apl','0002_administradores_empleados_tipo_identificador_and_more','2024-09-11 20:17:41.405360'),(8,'apl','0003_marcas_presentacion_proveedores_unidad_medida','2024-09-11 20:17:41.450290'),(9,'apl','0004_unidad_medida_estado_alter_clientes_telefono_and_more','2024-09-11 20:17:41.717460'),(10,'apl','0005_proveedores_apellido_alter_proveedores_nit','2024-09-11 20:17:41.733081'),(11,'apl','0006_alter_proveedores_apellido','2024-09-11 20:17:41.751984'),(12,'apl','0007_alter_proveedores_apellido','2024-09-11 20:17:41.756379'),(13,'apl','0008_metodo_pago','2024-09-11 20:17:41.769569'),(14,'apl','0009_compras','2024-09-11 20:17:41.879924'),(15,'apl','0010_alter_compras_fecha_compra','2024-09-11 20:17:41.918930'),(16,'apl','0011_alter_compras_fecha_compra','2024-09-11 20:17:41.954647'),(17,'apl','0012_alter_compras_fecha_compra','2024-09-11 20:17:41.989959'),(18,'apl','0013_ventas','2024-09-11 20:17:42.144527'),(19,'apl','0014_alter_ventas_administrador','2024-09-11 20:17:42.213209'),(20,'apl','0015_alter_proveedores_options','2024-09-11 20:17:42.213209'),(21,'apl','0016_alter_proveedores_options','2024-09-11 20:17:42.213209'),(22,'apl','0017_alter_administradores_correo_electronico_and_more','2024-09-11 20:17:42.267436'),(23,'apl','0018_ventas_ventas_cantidad_ventas_ventas_unidad_medida','2024-09-11 20:17:42.380226'),(24,'apl','0019_rename_ventas_unidad_medida_ventas_ventas_unidad_medida','2024-09-11 20:17:42.464767'),(25,'apl','0020_ventas_ventas_precio','2024-09-11 20:17:42.513274'),(26,'apl','0021_remove_ventas_ventas_precio','2024-09-11 20:17:42.535401'),(27,'apl','0022_remove_ventas_ventas_unidad_medida','2024-09-11 20:17:42.579996'),(28,'apl','0023_alter_productos_precio','2024-09-11 20:17:42.633975'),(29,'apl','0018_alter_clientes_nit_alter_productos_nombre_and_more','2024-09-11 20:17:42.684255'),(30,'apl','0024_merge_20240723_1317','2024-09-11 20:17:42.684255'),(31,'apl','0025_remove_compras_producto_detallecompra','2024-09-11 20:17:42.763873'),(32,'apl','0024_merge_20240722_1308','2024-09-11 20:17:42.780156'),(33,'apl','0026_merge_20240725_1420','2024-09-11 20:17:42.782153'),(34,'apl','0027_detallecompra_compra','2024-09-11 20:17:42.817260'),(35,'apl','0026_merge_20240726_1340','2024-09-11 20:17:42.830553'),(36,'apl','0028_merge_20240727_2154','2024-09-11 20:17:42.830553'),(37,'apl','0029_detallecompra_cantidad','2024-09-11 20:17:42.869029'),(38,'apl','0030_remove_administradores_apellido_and_more','2024-09-11 20:17:43.184613'),(39,'apl','0028_merge_20240726_1440','2024-09-11 20:17:43.184613'),(40,'apl','0031_merge_20240730_2018','2024-09-11 20:17:43.184613'),(41,'apl','0032_remove_ventas_administrador_and_more','2024-09-11 20:17:43.261730'),(42,'apl','0033_clicktracking','2024-09-11 20:17:43.301725'),(43,'apl','0034_delete_clicktracking','2024-09-11 20:17:43.314466'),(44,'apl','0035_detallecompra_finalizado','2024-09-11 20:17:43.341004'),(45,'apl','0036_alter_productos_precio','2024-09-11 20:17:43.349765'),(46,'apl','0037_detalleventa','2024-09-11 20:17:43.439151'),(47,'apl','0038_remove_ventas_producto_remove_ventas_ventas_cantidad_and_more','2024-09-11 20:17:43.547469'),(48,'apl','0039_remove_detallecompra_finalizado_compras_finalizado_and_more','2024-09-11 20:17:43.695472'),(49,'apl','0040_alter_ventas_metodo_pago','2024-09-11 20:17:43.789914'),(50,'apl','0041_alter_compras_finalizado_and_more','2024-09-11 20:17:43.832611'),(51,'apl','0042_alter_administradores_numero_documento_and_more','2024-09-11 20:17:43.835360'),(52,'apl','0043_tipo_identificador_estado','2024-09-11 20:17:43.870397'),(53,'apl','0044_alter_clientes_tipo_identificador','2024-09-11 20:17:43.875037'),(54,'apl','0045_alter_tipo_identificador_estado','2024-09-11 20:17:43.883696'),(55,'apl','0043_remove_ventas_empleado_compras_usuario_and_more','2024-09-11 20:17:44.046130'),(56,'apl','0046_merge_20240905_1409','2024-09-11 20:17:44.048968'),(57,'apl','0047_alter_marcas_estado_alter_productos_marcas_and_more','2024-09-11 20:17:44.196092'),(58,'apl','0048_alter_clientes_correo_electronico_and_more','2024-09-11 20:17:44.212474'),(59,'apl','0049_detallecompra_precio_unitario_and_more','2024-09-11 20:17:44.520162'),(60,'apl','0050_alter_compras_usuario_alter_ventas_usuario','2024-09-11 20:17:44.582984'),(61,'apl','0051_alter_proveedores_nit','2024-09-11 20:17:44.582984'),(62,'contenttypes','0002_remove_content_type_name','2024-09-11 20:17:44.632529'),(63,'auth','0002_alter_permission_name_max_length','2024-09-11 20:17:44.687890'),(64,'auth','0003_alter_user_email_max_length','2024-09-11 20:17:44.708316'),(65,'auth','0004_alter_user_username_opts','2024-09-11 20:17:44.719578'),(66,'auth','0005_alter_user_last_login_null','2024-09-11 20:17:44.755459'),(67,'auth','0006_require_contenttypes_0002','2024-09-11 20:17:44.755459'),(68,'auth','0007_alter_validators_add_error_messages','2024-09-11 20:17:44.771794'),(69,'auth','0008_alter_user_username_max_length','2024-09-11 20:17:44.814924'),(70,'auth','0009_alter_user_last_name_max_length','2024-09-11 20:17:44.867949'),(71,'auth','0010_alter_group_name_max_length','2024-09-11 20:17:44.884897'),(72,'auth','0011_update_proxy_permissions','2024-09-11 20:17:44.899372'),(73,'auth','0012_alter_user_first_name_max_length','2024-09-11 20:17:44.936125'),(74,'sessions','0001_initial','2024-09-11 20:17:44.972304');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('hy1bth9ilqzdpmzzzoxpstqn6hfur99x','.eJxVjDkOwjAURO_iGln53sCU9JzB-ltwACVSnFSIu0OkFFCNNO_NvEzBdallbTqXQczZgDn8doT80HEDcsfxNlmexmUeyG6K3Wmz10n0edndv4OKrX7XnE6ASMwduOCPGJLfEpQjJQlCTJm6KI7Fp867XmMUgqyaOEPuzfsD6n44TQ:1sycSg:cH8HHNVI6Nqdt9-tWuD1iGPtOEdVmAsuJ7tdz0PwJPs','2024-10-23 19:35:06.690564'),('yt99014ie0uxen0dklyhvf5soiyacdmj','.eJxVjEEOwiAQRe_C2hDKABWX7nsGMsyAVA0kpV0Z765NutDtf-_9lwi4rSVsPS1hZnERgzj9bhHpkeoO-I711iS1ui5zlLsiD9rl1Dg9r4f7d1Cwl2-NxinwZ5-9Bk8EbCwYbRVbRRFGsibpOJLSaJmjIZVwyIkpO3LgHYr3B8_mOCc:1soTnr:-jkA-Zs_x6AiOEFWilm1T8p50Mqrd7yza1ZVov3mbN4','2024-09-25 20:19:03.823996');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `edad` int unsigned NOT NULL,
  `cedula` bigint unsigned NOT NULL,
  `correo_electronico` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cedula` (`cedula`),
  CONSTRAINT `empleados_chk_1` CHECK ((`edad` >= 0)),
  CONSTRAINT `empleados_chk_2` CHECK ((`cedula` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marca`
--

DROP TABLE IF EXISTS `marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marca` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marca`
--

LOCK TABLES `marca` WRITE;
/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` VALUES (1,'Jones, Clark and Miller','Activo'),(2,'Martin Ltd','Activo'),(3,'Moore, Mitchell and Kent','Activo'),(4,'Fry-Smith','Activo'),(5,'Cain-Rivera','Activo'),(6,'Davis, Zimmerman and Cabrera','Activo'),(7,'Hahn Inc','Activo'),(8,'Sanders LLC','Activo'),(9,'Perez, Schmidt and Watts','Activo'),(10,'Diaz, Morrow and Li','Activo');
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metodo de pago`
--

DROP TABLE IF EXISTS `metodo de pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metodo de pago` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metodo de pago`
--

LOCK TABLES `metodo de pago` WRITE;
/*!40000 ALTER TABLE `metodo de pago` DISABLE KEYS */;
INSERT INTO `metodo de pago` VALUES (1,'Bag'),(2,'Class'),(3,'Common'),(4,'Ground'),(5,'Listen');
/*!40000 ALTER TABLE `metodo de pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presentacion`
--

DROP TABLE IF EXISTS `presentacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presentacion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presentacion`
--

LOCK TABLES `presentacion` WRITE;
/*!40000 ALTER TABLE `presentacion` DISABLE KEYS */;
INSERT INTO `presentacion` VALUES (1,'Phone stand significant.'),(2,'Television.'),(3,'Book now.'),(4,'Bill pressure.'),(5,'Start own green.'),(6,'Investment cold.'),(7,'Adult.'),(8,'Power thought.'),(9,'Work power alone.'),(10,'Young place stay.');
/*!40000 ALTER TABLE `presentacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `cantidad` int unsigned NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `marcas_id` bigint NOT NULL,
  `presentacion_id` bigint NOT NULL,
  `tipo_id` bigint NOT NULL,
  `unidad_medida_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Producto_marcas_id_84b6b146_fk_Marca_id` (`marcas_id`),
  KEY `Producto_presentacion_id_abd188df_fk_Presentacion_id` (`presentacion_id`),
  KEY `Producto_tipo_id_477475b4_fk_Tipo_id` (`tipo_id`),
  KEY `Producto_unidad_medida_id_493a22e2_fk_Unidad_Medida_id` (`unidad_medida_id`),
  CONSTRAINT `Producto_marcas_id_84b6b146_fk_Marca_id` FOREIGN KEY (`marcas_id`) REFERENCES `marca` (`id`),
  CONSTRAINT `Producto_presentacion_id_abd188df_fk_Presentacion_id` FOREIGN KEY (`presentacion_id`) REFERENCES `presentacion` (`id`),
  CONSTRAINT `Producto_tipo_id_477475b4_fk_Tipo_id` FOREIGN KEY (`tipo_id`) REFERENCES `tipo` (`id`),
  CONSTRAINT `Producto_unidad_medida_id_493a22e2_fk_Unidad_Medida_id` FOREIGN KEY (`unidad_medida_id`) REFERENCES `unidad_medida` (`id`),
  CONSTRAINT `producto_chk_1` CHECK ((`cantidad` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=501 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,'Appear',72,191.87,9,2,2,7),(2,'Remain',12,582.40,10,2,1,6),(3,'Black',23,461.22,4,1,4,9),(4,'International',48,92.57,8,3,5,8),(5,'Some',3,90.70,3,7,7,1),(6,'Bar',21,320.79,2,1,7,7),(7,'Play',95,40.30,5,6,8,2),(8,'Sometimes',38,406.78,1,1,3,10),(9,'We',83,909.89,7,8,4,2),(10,'Me',7,359.94,2,3,6,6),(11,'He',12,885.20,3,10,9,6),(12,'Shake',5,349.82,9,9,7,5),(13,'Call',71,703.49,5,9,9,2),(14,'Unit',79,162.37,3,8,5,6),(15,'Region',37,955.67,8,9,7,10),(16,'Lead',41,557.92,3,3,1,1),(17,'Expect',55,283.52,9,8,9,1),(18,'Fight',45,905.43,8,2,1,2),(19,'My',80,863.32,3,3,10,5),(20,'Realize',44,938.39,4,7,4,5),(21,'Democrat',9,295.91,5,7,6,2),(22,'Represent',89,988.78,8,7,5,9),(23,'Author',67,351.08,7,2,2,7),(24,'Hot',5,321.15,10,6,3,1),(25,'Day',39,32.51,10,4,3,9),(26,'Career',28,435.98,6,4,5,8),(27,'Treat',95,679.79,4,7,7,10),(28,'Final',95,388.28,10,8,9,2),(29,'Start',71,591.86,2,10,3,5),(30,'Bar',4,983.07,4,4,9,7),(31,'Machine',29,847.42,6,5,5,6),(32,'First',86,126.38,1,1,1,2),(33,'Garden',62,177.45,1,4,8,4),(34,'Check',47,541.18,3,5,1,4),(35,'Car',9,76.31,4,3,7,9),(36,'Myself',85,914.25,9,6,4,6),(37,'True',74,542.64,2,8,6,1),(38,'Beyond',84,612.99,8,1,3,1),(39,'Right',99,144.51,4,5,3,6),(40,'Ground',26,955.05,1,7,6,10),(41,'Their',53,599.11,7,9,4,4),(42,'Price',41,227.01,10,4,10,4),(43,'Let',100,383.00,4,1,5,7),(44,'Spring',66,136.91,2,4,2,1),(45,'Season',52,210.67,3,8,5,9),(46,'Realize',66,37.27,5,6,1,8),(47,'On',44,466.98,10,6,4,5),(48,'This',48,323.63,3,7,3,2),(49,'Character',50,584.90,9,9,4,4),(50,'Someone',95,160.64,9,4,3,6),(51,'Community',17,229.92,2,6,1,5),(52,'Should',54,247.14,8,10,7,1),(53,'Especially',75,504.91,2,3,9,1),(54,'Moment',97,712.45,8,5,8,3),(55,'Professor',90,539.78,4,2,9,2),(56,'Day',95,48.95,6,4,2,6),(57,'Study',79,409.09,9,8,5,8),(58,'Good',32,182.47,8,8,10,5),(59,'Would',62,283.65,4,7,2,4),(60,'Appear',9,639.62,10,9,8,10),(61,'West',90,937.47,6,3,4,1),(62,'Approach',93,177.22,8,3,6,2),(63,'Do',3,78.46,10,10,5,4),(64,'Society',99,877.89,4,8,6,10),(65,'Discussion',98,150.82,3,1,2,7),(66,'Drug',80,626.66,5,10,10,8),(67,'Care',99,847.02,8,2,9,10),(68,'Firm',40,586.24,5,7,9,7),(69,'Protect',39,953.36,5,1,2,6),(70,'Cover',77,73.49,6,8,10,8),(71,'Such',8,142.58,5,10,5,5),(72,'Personal',76,496.43,3,4,7,5),(73,'Prepare',53,110.95,4,10,1,3),(74,'Usually',58,365.84,6,6,4,10),(75,'Anyone',7,781.61,3,6,7,6),(76,'Heart',66,225.06,6,3,1,8),(77,'Baby',6,423.45,5,5,3,4),(78,'Consumer',23,395.16,3,4,8,9),(79,'Everything',86,532.82,4,8,4,1),(80,'Establish',34,198.69,4,1,8,1),(81,'Hospital',17,665.16,2,7,3,8),(82,'No',23,573.30,4,6,5,7),(83,'Still',9,241.35,4,5,3,10),(84,'Including',16,93.94,10,1,4,3),(85,'Research',88,303.15,1,5,5,3),(86,'American',7,262.37,8,3,3,3),(87,'Computer',93,349.34,3,2,7,9),(88,'Finally',92,978.26,8,8,3,3),(89,'Cell',6,360.83,5,9,5,9),(90,'Hot',34,446.24,10,6,6,1),(91,'Decision',27,621.83,6,10,9,8),(92,'Become',42,827.40,3,8,6,4),(93,'Challenge',15,463.55,4,8,8,9),(94,'If',75,538.46,5,10,4,4),(95,'Today',9,200.91,4,2,2,10),(96,'When',31,384.71,3,2,6,10),(97,'Television',19,177.29,9,8,10,8),(98,'Data',41,883.71,1,4,3,9),(99,'Goal',54,435.68,3,4,1,6),(100,'Change',100,813.39,8,2,7,2),(101,'Participant',86,13.26,6,10,6,4),(102,'New',32,222.60,5,6,9,2),(103,'Peace',11,49.74,5,5,6,9),(104,'Campaign',76,241.70,8,7,8,5),(105,'Tv',40,187.95,9,1,2,7),(106,'Successful',20,960.44,2,9,2,8),(107,'Candidate',10,145.05,9,7,3,3),(108,'Easy',91,415.43,8,1,1,6),(109,'Consider',91,602.90,3,5,4,2),(110,'Bar',12,917.70,8,2,5,2),(111,'Civil',52,688.06,1,6,5,8),(112,'I',2,607.69,9,6,4,7),(113,'Nearly',64,588.68,6,5,5,4),(114,'Expert',92,418.54,1,6,8,9),(115,'Front',5,815.38,1,5,5,4),(116,'Total',30,595.23,2,8,5,8),(117,'Safe',12,384.64,1,3,2,10),(118,'Commercial',96,519.17,9,4,3,4),(119,'Enter',51,369.39,2,8,1,3),(120,'Dinner',24,271.63,1,7,1,2),(121,'Voice',5,627.60,2,2,5,10),(122,'Southern',81,909.76,7,1,4,6),(123,'Modern',25,225.49,5,10,9,1),(124,'Teach',83,893.52,8,9,1,2),(125,'Become',18,306.82,5,7,4,7),(126,'Individual',48,937.78,2,3,4,6),(127,'Yeah',32,183.78,10,10,9,7),(128,'Language',70,317.02,3,9,3,9),(129,'Offer',50,703.57,7,4,10,3),(130,'Would',47,277.35,2,5,5,1),(131,'Sell',43,572.43,10,1,10,9),(132,'Just',36,273.22,10,2,8,2),(133,'Real',67,589.17,6,6,9,2),(134,'Name',61,910.69,1,3,5,3),(135,'Clearly',62,241.62,2,5,9,4),(136,'Career',99,127.49,7,3,10,6),(137,'Blood',12,130.94,7,10,7,1),(138,'Theory',37,886.90,3,1,7,10),(139,'Eight',24,785.21,7,8,9,5),(140,'Someone',93,131.32,3,1,8,9),(141,'Explain',77,61.69,10,9,6,5),(142,'Out',57,552.73,9,5,3,7),(143,'Agency',40,101.87,1,3,2,6),(144,'How',75,846.88,8,6,9,4),(145,'Although',3,775.04,1,1,5,8),(146,'Allow',51,981.13,7,1,7,8),(147,'Customer',38,875.92,3,10,3,9),(148,'Ok',18,126.55,8,4,3,10),(149,'Wife',81,978.52,4,5,10,5),(150,'Reveal',39,849.33,1,9,5,6),(151,'Fund',83,972.79,9,1,7,2),(152,'Heavy',24,265.65,1,1,3,3),(153,'Chance',23,284.72,5,2,5,7),(154,'But',43,207.74,9,5,5,1),(155,'Guess',38,153.73,7,7,10,7),(156,'Thought',69,991.38,6,1,1,4),(157,'Ground',1,477.93,10,9,10,9),(158,'Bank',46,378.19,8,10,1,6),(159,'Tonight',87,148.65,9,8,3,6),(160,'Claim',65,283.66,2,10,2,3),(161,'Finally',53,498.63,4,10,3,5),(162,'Mission',60,575.95,10,8,1,9),(163,'Major',56,565.50,8,1,10,8),(164,'Consider',80,60.34,9,3,7,5),(165,'Quite',14,567.42,8,5,6,10),(166,'Sign',65,755.71,3,7,8,3),(167,'Media',13,629.44,10,9,10,4),(168,'Guy',82,37.96,10,9,6,5),(169,'Door',41,916.44,10,4,5,2),(170,'Get',39,809.03,6,1,5,10),(171,'Those',54,50.15,10,9,8,7),(172,'Contain',59,987.41,3,9,7,3),(173,'True',95,249.56,7,4,4,7),(174,'Ten',51,38.65,10,5,1,5),(175,'What',73,52.97,7,6,6,5),(176,'List',71,444.01,7,5,4,5),(177,'Player',90,892.00,10,4,1,9),(178,'Five',8,459.67,4,3,1,2),(179,'Tonight',98,259.08,10,8,6,6),(180,'Relationship',64,352.93,7,5,5,10),(181,'Others',64,18.48,1,10,4,9),(182,'Development',84,331.51,10,4,2,5),(183,'Task',99,599.74,8,9,6,5),(184,'Officer',31,980.14,2,8,4,8),(185,'Commercial',71,368.06,10,4,3,6),(186,'Remain',89,283.49,3,10,5,5),(187,'Will',78,282.61,7,9,8,8),(188,'Participant',41,862.56,1,4,10,6),(189,'Often',51,500.57,9,8,3,2),(190,'Program',100,920.56,10,3,2,9),(191,'School',27,788.13,1,8,7,7),(192,'Thousand',12,503.08,8,9,5,2),(193,'More',30,983.11,5,5,8,7),(194,'Network',62,554.87,7,7,9,2),(195,'Ahead',78,727.92,8,1,3,4),(196,'Statement',91,769.57,4,9,9,10),(197,'Feeling',32,17.61,4,9,5,6),(198,'Enjoy',55,912.91,6,10,3,7),(199,'Decision',94,302.26,4,7,2,9),(200,'Attention',82,761.92,1,2,4,9),(201,'Available',9,580.38,9,6,4,9),(202,'Relationship',38,700.90,7,8,9,9),(203,'Ten',38,823.22,1,10,1,7),(204,'Threat',13,224.65,10,7,5,2),(205,'Almost',62,211.56,5,1,9,5),(206,'Too',39,952.40,6,2,10,4),(207,'Ball',21,959.40,7,3,8,8),(208,'Cup',8,420.73,5,6,8,5),(209,'Sit',5,868.67,1,2,6,9),(210,'Probably',72,553.52,3,9,4,10),(211,'Instead',46,213.41,8,8,2,8),(212,'Your',64,251.94,4,2,4,6),(213,'Wait',56,212.92,9,7,2,1),(214,'Trial',21,714.15,7,1,2,5),(215,'Training',93,568.93,5,7,2,1),(216,'Current',99,525.82,4,4,6,5),(217,'Boy',14,646.03,3,5,4,9),(218,'Itself',14,646.02,5,7,9,1),(219,'Small',3,237.01,1,10,3,2),(220,'Dinner',11,886.92,1,3,2,8),(221,'Particularly',91,635.18,2,8,10,10),(222,'Authority',20,189.61,9,9,8,3),(223,'Reduce',1,894.14,4,10,6,10),(224,'Really',5,574.45,2,3,4,10),(225,'Same',10,459.22,1,1,10,4),(226,'Administration',76,474.78,3,8,5,8),(227,'Tax',11,250.35,5,9,6,10),(228,'Professor',42,661.93,4,7,2,10),(229,'Different',57,763.24,8,8,6,3),(230,'Goal',65,219.50,3,6,3,3),(231,'Situation',83,16.98,2,4,2,1),(232,'Learn',44,964.48,9,3,5,3),(233,'College',44,88.91,6,9,1,7),(234,'Three',4,350.29,4,6,9,9),(235,'Soldier',72,355.41,2,8,8,10),(236,'Chair',48,680.74,5,7,3,2),(237,'Require',78,912.06,1,9,2,4),(238,'Small',49,970.43,10,6,2,10),(239,'Sport',24,377.71,6,3,9,9),(240,'Process',92,28.48,2,7,4,8),(241,'Focus',67,977.25,9,2,2,4),(242,'Movie',6,793.11,7,5,2,10),(243,'Against',25,894.09,9,4,9,8),(244,'Paper',20,500.23,7,2,1,10),(245,'Probably',23,628.61,8,5,7,5),(246,'Activity',35,120.57,7,9,6,7),(247,'All',45,323.19,1,4,6,3),(248,'Compare',58,949.47,2,6,9,9),(249,'Happy',95,195.06,3,2,10,6),(250,'Herself',18,286.11,6,6,9,2),(251,'Some',40,197.12,6,8,8,7),(252,'Woman',52,637.56,2,9,2,4),(253,'Race',22,627.27,3,1,1,9),(254,'Approach',26,845.19,1,8,2,7),(255,'Watch',97,327.72,6,2,10,4),(256,'Class',2,127.89,5,8,4,2),(257,'Traditional',23,592.53,5,1,3,5),(258,'Standard',4,999.78,3,9,7,5),(259,'Continue',23,656.71,9,8,4,8),(260,'Support',62,155.17,10,2,8,2),(261,'Each',25,682.34,10,8,6,8),(262,'Agreement',19,486.54,7,7,7,2),(263,'Simple',16,718.41,6,10,7,7),(264,'Serve',31,520.36,1,5,3,10),(265,'Accept',95,374.87,1,4,5,2),(266,'Economy',24,31.34,10,8,8,1),(267,'Worker',5,871.98,6,5,5,1),(268,'Walk',17,445.69,7,5,5,6),(269,'More',27,600.96,1,3,7,6),(270,'Successful',53,936.44,8,6,2,10),(271,'Focus',94,939.71,9,9,6,2),(272,'Cell',29,385.50,5,6,4,1),(273,'Money',41,118.84,4,3,4,2),(274,'Century',25,591.31,6,1,4,7),(275,'Short',77,227.95,9,9,3,7),(276,'Child',53,304.66,9,6,10,3),(277,'Quality',91,297.09,8,6,4,9),(278,'Particular',34,139.22,7,3,4,7),(279,'Some',91,745.79,6,5,10,7),(280,'Among',37,902.40,4,1,5,1),(281,'Move',87,117.18,2,8,3,10),(282,'Outside',33,158.29,5,3,2,7),(283,'Apply',22,103.71,4,3,7,1),(284,'Social',47,604.16,6,8,6,5),(285,'Do',41,571.72,6,8,9,6),(286,'Institution',90,669.69,1,10,9,6),(287,'Edge',82,761.00,8,9,10,3),(288,'Money',60,222.92,4,5,9,3),(289,'To',99,493.38,10,4,1,2),(290,'Remember',17,641.81,5,2,4,2),(291,'Impact',91,435.08,9,5,10,3),(292,'Pm',10,974.29,5,6,7,5),(293,'Least',81,816.45,2,9,3,6),(294,'Condition',80,793.91,9,7,8,2),(295,'Summer',38,162.41,7,5,8,2),(296,'Like',24,736.02,6,4,10,8),(297,'Pattern',84,695.91,4,10,2,9),(298,'Most',80,108.29,5,4,5,4),(299,'Help',29,770.70,5,7,4,9),(300,'Tree',18,819.71,1,3,8,4),(301,'Understand',33,369.55,2,3,3,8),(302,'Consumer',64,959.50,6,3,5,6),(303,'Kid',99,694.96,7,4,3,9),(304,'Machine',15,498.43,1,7,4,7),(305,'Group',16,487.75,5,3,10,6),(306,'Moment',53,161.17,6,10,4,5),(307,'Resource',20,402.58,9,2,7,5),(308,'Mind',54,893.13,3,10,5,6),(309,'Culture',14,278.34,5,9,4,2),(310,'Cultural',93,510.59,4,9,2,6),(311,'Report',13,228.57,4,4,9,9),(312,'Country',17,835.31,1,5,4,3),(313,'Energy',63,984.63,2,7,2,3),(314,'Morning',21,662.39,8,4,2,7),(315,'Become',34,231.46,8,5,6,10),(316,'Concern',100,855.66,4,9,4,1),(317,'Position',22,807.92,9,9,1,5),(318,'Down',15,751.97,3,8,6,6),(319,'Attorney',98,459.69,7,5,1,3),(320,'Trial',32,150.95,1,7,2,7),(321,'Remain',79,216.06,3,4,4,8),(322,'Green',11,668.47,1,7,5,2),(323,'Country',13,845.36,3,6,10,8),(324,'Leg',51,600.64,5,6,6,4),(325,'Student',66,146.45,6,6,8,6),(326,'Laugh',95,81.20,10,7,7,4),(327,'Pretty',54,630.55,7,4,4,7),(328,'Worker',96,493.61,3,5,3,4),(329,'Firm',9,104.80,9,6,3,8),(330,'Imagine',76,29.09,1,6,9,4),(331,'Although',87,260.06,9,2,4,5),(332,'Detail',34,979.60,4,8,2,7),(333,'Financial',35,862.79,7,10,2,3),(334,'Organization',67,992.30,6,4,1,3),(335,'Manage',28,721.07,5,1,5,5),(336,'Onto',6,755.26,7,2,3,3),(337,'City',100,850.02,7,7,6,5),(338,'Process',39,37.68,6,5,2,5),(339,'Large',20,616.28,9,8,8,8),(340,'First',95,453.29,10,3,6,10),(341,'Bank',68,850.43,2,2,6,4),(342,'Project',32,706.52,6,1,1,5),(343,'Always',85,921.00,4,5,9,7),(344,'Stop',6,600.43,9,1,8,3),(345,'Before',20,409.01,5,4,4,9),(346,'Break',80,605.91,5,6,10,2),(347,'Next',58,135.00,5,9,8,1),(348,'Responsibility',10,619.56,1,6,1,8),(349,'Range',82,48.32,2,2,7,7),(350,'Improve',2,332.55,9,3,10,4),(351,'Window',62,47.75,2,4,5,1),(352,'Unit',24,910.87,3,3,2,1),(353,'Drug',51,209.17,1,7,3,2),(354,'Energy',27,353.30,4,2,6,5),(355,'Water',77,482.83,8,7,3,6),(356,'Manage',41,704.73,7,4,8,6),(357,'Since',71,75.56,4,7,2,9),(358,'Rich',39,914.35,5,10,5,8),(359,'Sing',76,599.55,5,3,1,8),(360,'Such',4,775.76,1,1,10,3),(361,'Book',20,154.29,10,4,2,5),(362,'People',6,739.30,7,3,2,1),(363,'Realize',31,825.98,5,3,2,4),(364,'Detail',32,366.11,3,7,5,10),(365,'Kitchen',46,283.53,10,2,1,7),(366,'Sort',70,790.08,1,9,1,9),(367,'Use',69,133.21,4,2,6,6),(368,'Most',82,562.50,2,9,1,2),(369,'Pick',91,135.97,9,3,1,10),(370,'Artist',83,242.52,8,1,5,5),(371,'Job',88,185.81,1,10,9,1),(372,'News',35,217.82,2,2,4,3),(373,'Plan',62,908.61,1,10,5,10),(374,'Position',36,861.95,4,10,5,7),(375,'Whole',18,453.00,4,3,4,2),(376,'Me',87,498.23,7,9,3,1),(377,'Between',53,864.45,6,5,4,10),(378,'Keep',75,320.95,6,5,7,3),(379,'Stay',27,960.50,4,7,9,1),(380,'Card',90,972.87,1,3,3,8),(381,'Compare',76,139.04,6,5,8,10),(382,'Difference',39,860.32,8,4,5,4),(383,'Gun',41,54.54,1,6,4,9),(384,'Husband',54,391.21,6,1,8,8),(385,'Piece',64,384.84,9,3,4,6),(386,'Book',93,490.59,2,8,3,7),(387,'Down',29,751.81,5,5,10,7),(388,'Radio',34,63.10,10,1,2,1),(389,'Tax',26,128.58,4,4,7,1),(390,'Sport',80,255.43,5,4,8,1),(391,'Quickly',12,926.52,3,7,5,6),(392,'Design',35,501.35,10,7,2,10),(393,'Brother',2,23.41,5,10,7,6),(394,'Kid',10,10.17,8,3,5,4),(395,'Every',37,302.52,4,9,8,6),(396,'Clear',75,465.20,8,1,6,7),(397,'Nearly',97,183.91,5,3,6,2),(398,'Join',99,691.70,8,9,8,1),(399,'Mention',81,388.62,9,9,8,8),(400,'Blue',37,285.32,10,8,2,5),(401,'Work',93,231.58,1,7,6,5),(402,'Group',18,410.17,10,9,7,7),(403,'Of',99,84.71,8,6,5,1),(404,'Very',83,649.70,7,3,3,4),(405,'Wide',20,777.00,10,5,3,5),(406,'House',90,527.24,8,1,3,2),(407,'Threat',94,17.64,3,5,5,8),(408,'Such',19,537.17,10,8,6,5),(409,'Street',18,905.60,1,4,6,1),(410,'Break',63,907.89,10,10,9,2),(411,'Process',67,418.20,3,6,1,6),(412,'Education',91,489.26,7,7,1,8),(413,'Growth',99,270.57,1,7,7,7),(414,'Market',70,146.06,1,5,5,4),(415,'Recent',86,18.97,2,8,4,6),(416,'Health',40,924.03,7,2,8,8),(417,'Military',19,348.17,4,1,10,2),(418,'Practice',65,196.90,4,9,1,6),(419,'Training',32,620.84,10,10,8,7),(420,'State',11,866.12,10,7,3,7),(421,'Training',95,904.84,3,7,10,1),(422,'Herself',37,626.72,2,1,5,7),(423,'Heart',46,917.37,10,4,4,10),(424,'Cell',99,864.55,1,7,10,3),(425,'Provide',78,839.84,9,2,7,2),(426,'Result',2,119.05,1,2,1,10),(427,'Notice',85,642.49,8,8,10,3),(428,'Program',26,546.53,5,4,10,2),(429,'Deal',100,187.78,7,8,7,9),(430,'Type',79,315.10,9,3,5,9),(431,'Well',71,414.20,1,4,1,4),(432,'Certainly',64,554.15,8,3,2,6),(433,'Town',32,401.91,1,4,1,8),(434,'Economic',58,680.07,8,9,10,6),(435,'None',80,924.64,8,10,9,10),(436,'People',25,362.72,2,10,5,3),(437,'Practice',37,709.96,5,9,3,7),(438,'Modern',29,684.66,3,3,10,7),(439,'Attack',68,255.90,4,1,3,10),(440,'Oil',3,699.54,4,8,9,9),(441,'Writer',10,907.90,10,4,8,10),(442,'Painting',40,206.45,7,7,4,8),(443,'Vote',24,936.37,4,7,8,8),(444,'High',74,74.26,6,9,10,5),(445,'Ask',60,517.83,6,9,7,6),(446,'Center',67,772.55,4,9,7,7),(447,'Bad',51,633.27,3,10,10,9),(448,'Scene',24,244.30,6,3,10,9),(449,'Relationship',5,686.78,6,2,8,9),(450,'Bit',17,412.13,10,3,5,10),(451,'Section',69,366.19,6,4,9,7),(452,'Daughter',36,534.10,3,5,1,10),(453,'Home',83,717.42,5,6,3,5),(454,'Today',11,959.23,7,2,9,1),(455,'Consider',70,922.35,5,6,6,4),(456,'Behavior',50,562.17,4,8,7,4),(457,'Agree',98,295.81,7,4,10,2),(458,'Also',59,168.64,9,5,2,2),(459,'Six',29,256.51,4,9,1,9),(460,'Personal',47,499.99,5,9,7,7),(461,'More',21,517.76,3,9,1,4),(462,'Course',81,311.71,6,4,6,5),(463,'Instead',51,357.71,10,10,7,8),(464,'Seat',67,952.72,1,9,3,6),(465,'This',12,241.69,10,3,2,3),(466,'Food',99,208.49,10,5,10,4),(467,'Figure',69,481.17,2,7,6,8),(468,'Wind',61,575.19,9,6,8,8),(469,'Treatment',98,711.45,8,4,10,10),(470,'Break',11,831.10,6,7,9,10),(471,'Yourself',14,507.46,9,2,10,6),(472,'Tonight',13,131.69,7,6,6,9),(473,'Between',100,246.04,10,6,10,1),(474,'Law',60,833.22,6,4,9,4),(475,'Between',37,880.92,2,1,4,5),(476,'School',94,225.81,5,2,10,1),(477,'Artist',9,267.46,3,2,3,3),(478,'Operation',27,269.34,7,9,7,6),(479,'Deep',60,110.53,3,8,9,4),(480,'Hundred',49,845.65,3,8,5,7),(481,'Accept',66,942.26,5,7,10,5),(482,'Skill',98,96.23,10,5,3,5),(483,'Control',7,412.84,1,2,9,7),(484,'Your',48,932.71,6,6,1,6),(485,'Rock',70,334.12,7,1,9,3),(486,'Almost',27,539.50,3,2,2,2),(487,'Specific',53,549.03,10,5,8,8),(488,'Program',58,731.08,9,2,6,10),(489,'Fact',43,153.23,9,4,2,7),(490,'Because',11,556.04,9,2,10,1),(491,'On',7,519.24,9,1,10,10),(492,'Dog',39,522.16,6,9,9,10),(493,'Grow',93,928.03,10,3,2,10),(494,'Science',60,893.73,4,8,3,5),(495,'Medical',100,515.03,5,5,1,10),(496,'Guy',99,845.38,2,10,1,8),(497,'Ready',64,788.80,7,6,9,7),(498,'Window',56,895.18,6,3,9,9),(499,'Just',68,461.06,2,7,5,9),(500,'Stand',53,256.30,9,5,1,6);
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `nit` varchar(20) NOT NULL,
  `ubicacion` varchar(255) NOT NULL,
  `telefono` int unsigned NOT NULL,
  `correo_electronico` varchar(100) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nit` (`nit`),
  CONSTRAINT `Proveedores_telefono_ae938b67_check` CHECK ((`telefono` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Evelyn','9447322048','77866 Blevins Springs Suite 201\nPort Emilychester, GU 60800',95564590,'michaela08@example.org','Hill'),(2,'Sean','8554762884','9408 Rita Street Suite 280\nGreenmouth, KS 30846',98569247,'chaseapril@example.com','Lucas'),(3,'Patrick','1601815440','7828 Nicholas Spur\nNorth Gregory, PW 99223',15190182,'vanessabishop@example.net','Martin'),(4,'Margaret','4433853639','493 Chris Lock Apt. 199\nNorth Dawnstad, MN 12440',13829184,'johnwerner@example.com','Ingram'),(5,'Michael','4638296037','USCGC Erickson\nFPO AP 41940',64704101,'moralesjim@example.net','Kane'),(6,'Brandon','6523322052','816 Willie Manors Apt. 802\nSouth Richard, WV 26672',86827284,'justin40@example.com','Sanders'),(7,'William','407491407','196 Donald Orchard Apt. 461\nLake Tiffany, MS 95403',53302172,'uanderson@example.com','Hebert'),(8,'Ashley','4574713417','573 Anderson Stream Suite 557\nWilliamsside, UT 70634',72169290,'andersondana@example.com','Ortiz'),(9,'Robert','7125229181','01600 Trevor Fork Suite 904\nPattersonside, PR 20708',81182105,'wagnerreginald@example.net','Washington'),(10,'Robert','2689642978','0532 Ruben Prairie\nLake Sophiaborough, KS 20086',34361942,'lisajohnson@example.org','Webster');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo`
--

DROP TABLE IF EXISTS `tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) DEFAULT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Tipo_nombre_f386ac74_uniq` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo`
--

LOCK TABLES `tipo` WRITE;
/*!40000 ALTER TABLE `tipo` DISABLE KEYS */;
INSERT INTO `tipo` VALUES (1,'Should','Activo'),(2,'Manager','Activo'),(3,'Remember','Activo'),(4,'Area','Activo'),(5,'Under','Activo'),(6,'Letter','Activo'),(7,'This','Activo'),(8,'Herself','Activo'),(9,'Inside','Activo'),(10,'Color','Activo');
/*!40000 ALTER TABLE `tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_identificador`
--

DROP TABLE IF EXISTS `tipo_identificador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_identificador` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_identificador`
--

LOCK TABLES `tipo_identificador` WRITE;
/*!40000 ALTER TABLE `tipo_identificador` DISABLE KEYS */;
INSERT INTO `tipo_identificador` VALUES (1,'Fish','Activo'),(2,'Resource','Activo'),(3,'Hot','Activo'),(4,'Southern','Activo'),(5,'Many','Activo');
/*!40000 ALTER TABLE `tipo_identificador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidad_medida`
--

DROP TABLE IF EXISTS `unidad_medida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidad_medida` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_medida`
--

LOCK TABLES `unidad_medida` WRITE;
/*!40000 ALTER TABLE `unidad_medida` DISABLE KEYS */;
INSERT INTO `unidad_medida` VALUES (1,'West','Activo'),(2,'Scientist','Activo'),(3,'West','Activo'),(4,'While','Activo'),(5,'Expect','Activo'),(6,'Few','Activo'),(7,'Current','Activo'),(8,'Smile','Activo'),(9,'Authority','Activo'),(10,'Huge','Activo');
/*!40000 ALTER TABLE `unidad_medida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime(6) NOT NULL,
  `cliente_id` bigint NOT NULL,
  `metodo_pago_id` bigint DEFAULT NULL,
  `finalizado` tinyint(1) NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Venta_cliente_id_a2b0be2d_fk_Cliente_id` (`cliente_id`),
  KEY `Venta_metodo_pago_id_8a17bfb8_fk_Metodo de pago_id` (`metodo_pago_id`),
  CONSTRAINT `Venta_cliente_id_a2b0be2d_fk_Cliente_id` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`),
  CONSTRAINT `Venta_metodo_pago_id_8a17bfb8_fk_Metodo de pago_id` FOREIGN KEY (`metodo_pago_id`) REFERENCES `metodo de pago` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
INSERT INTO `venta` VALUES (1,'2024-09-11 21:33:24.514462',7,5,0,'paulafrank'),(2,'2024-09-11 21:33:24.514462',2,1,1,'garciajudy'),(3,'2024-09-11 21:33:24.514462',8,2,1,'zachary12'),(4,'2024-09-11 21:33:24.514462',3,2,0,'tracycross'),(5,'2024-09-11 21:33:24.514462',2,3,0,'robert87'),(6,'2024-09-11 21:33:24.514462',8,5,0,'nguyencharles'),(7,'2024-09-11 21:33:24.514462',1,5,0,'cassandra90'),(8,'2024-09-11 21:33:24.514462',4,5,0,'haleclaudia'),(9,'2024-09-11 21:33:24.514462',1,4,0,'kirstengriffin'),(10,'2024-09-11 21:33:24.514462',3,2,0,'stevensims'),(11,'2024-09-11 21:34:53.460232',1,1,0,'CRIS');
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-09 14:37:31
