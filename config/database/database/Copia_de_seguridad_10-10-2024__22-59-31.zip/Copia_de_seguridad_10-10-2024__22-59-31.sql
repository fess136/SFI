-- MySQL dump 10.13  Distrib 8.0.39, for Win64 (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `conf_contrasena` varchar(128) NOT NULL,
  `contrasena` varchar(128) NOT NULL,
  `numero_documento` int unsigned NOT NULL,
  `telefono` int unsigned NOT NULL,
  `user_id` int NOT NULL,
  `tipo_documento_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_documento` (`numero_documento`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `Administrador_tipo_documento_id_d055d673` (`tipo_documento_id`),
  CONSTRAINT `Administrador_tipo_documento_id_d055d673_fk_Tipo_iden` FOREIGN KEY (`tipo_documento_id`) REFERENCES `tipo_identificador` (`id`),
  CONSTRAINT `Administrador_user_id_949907f5_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `administrador_chk_1` CHECK ((`numero_documento` >= 0)),
  CONSTRAINT `administrador_chk_2` CHECK ((`telefono` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apl_detallecompra`
--

DROP TABLE IF EXISTS `apl_detallecompra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apl_detallecompra` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `producto_id` bigint NOT NULL,
  `compra_id` bigint NOT NULL,
  `cantidad` int unsigned DEFAULT NULL,
  `precio_unitario` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `apl_detallecompra_producto_id_96576587_fk_Producto_id` (`producto_id`),
  KEY `apl_detallecompra_compra_id_3a0209a2_fk_Compra_id` (`compra_id`),
  CONSTRAINT `apl_detallecompra_compra_id_3a0209a2_fk_Compra_id` FOREIGN KEY (`compra_id`) REFERENCES `compra` (`id`),
  CONSTRAINT `apl_detallecompra_producto_id_96576587_fk_Producto_id` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`),
  CONSTRAINT `apl_detallecompra_chk_1` CHECK ((`cantidad` >= 0)),
  CONSTRAINT `apl_detallecompra_chk_2` CHECK ((`precio_unitario` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apl_detallecompra`
--

LOCK TABLES `apl_detallecompra` WRITE;
/*!40000 ALTER TABLE `apl_detallecompra` DISABLE KEYS */;
/*!40000 ALTER TABLE `apl_detallecompra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apl_detalleventa`
--

DROP TABLE IF EXISTS `apl_detalleventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apl_detalleventa` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int unsigned NOT NULL,
  `producto_id` bigint NOT NULL,
  `venta_id` bigint NOT NULL,
  `precio_unitario` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `apl_detalleventa_producto_id_f3556a55_fk_Producto_id` (`producto_id`),
  KEY `apl_detalleventa_venta_id_3bab7eea_fk_Venta_id` (`venta_id`),
  CONSTRAINT `apl_detalleventa_producto_id_f3556a55_fk_Producto_id` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`),
  CONSTRAINT `apl_detalleventa_venta_id_3bab7eea_fk_Venta_id` FOREIGN KEY (`venta_id`) REFERENCES `venta` (`id`),
  CONSTRAINT `apl_detalleventa_chk_1` CHECK ((`cantidad` >= 0)),
  CONSTRAINT `apl_detalleventa_chk_2` CHECK ((`precio_unitario` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apl_detalleventa`
--

LOCK TABLES `apl_detalleventa` WRITE;
/*!40000 ALTER TABLE `apl_detalleventa` DISABLE KEYS */;
/*!40000 ALTER TABLE `apl_detalleventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add Tipo',7,'add_tipo'),(26,'Can change Tipo',7,'change_tipo'),(27,'Can delete Tipo',7,'delete_tipo'),(28,'Can view Tipo',7,'view_tipo'),(29,'Can add Administrador',8,'add_administradores'),(30,'Can change Administrador',8,'change_administradores'),(31,'Can delete Administrador',8,'delete_administradores'),(32,'Can view Administrador',8,'view_administradores'),(33,'Can add Tipo Identificador',9,'add_tipo_identificador'),(34,'Can change Tipo Identificador',9,'change_tipo_identificador'),(35,'Can delete Tipo Identificador',9,'delete_tipo_identificador'),(36,'Can view Tipo Identificador',9,'view_tipo_identificador'),(37,'Can add Cliente',10,'add_clientes'),(38,'Can change Cliente',10,'change_clientes'),(39,'Can delete Cliente',10,'delete_clientes'),(40,'Can view Cliente',10,'view_clientes'),(41,'Can add Marca',11,'add_marcas'),(42,'Can change Marca',11,'change_marcas'),(43,'Can delete Marca',11,'delete_marcas'),(44,'Can view Marca',11,'view_marcas'),(45,'Can add Presentación',12,'add_presentacion'),(46,'Can change Presentación',12,'change_presentacion'),(47,'Can delete Presentación',12,'delete_presentacion'),(48,'Can view Presentación',12,'view_presentacion'),(49,'Can add Proveedor',13,'add_proveedores'),(50,'Can change Proveedor',13,'change_proveedores'),(51,'Can delete Proveedor',13,'delete_proveedores'),(52,'Can view Proveedor',13,'view_proveedores'),(53,'Can add Unidad de Medida',14,'add_unidad_medida'),(54,'Can change Unidad de Medida',14,'change_unidad_medida'),(55,'Can delete Unidad de Medida',14,'delete_unidad_medida'),(56,'Can view Unidad de Medida',14,'view_unidad_medida'),(57,'Can add Producto',15,'add_productos'),(58,'Can change Producto',15,'change_productos'),(59,'Can delete Producto',15,'delete_productos'),(60,'Can view Producto',15,'view_productos'),(61,'Can add Metodo de pago',16,'add_metodo_pago'),(62,'Can change Metodo de pago',16,'change_metodo_pago'),(63,'Can delete Metodo de pago',16,'delete_metodo_pago'),(64,'Can view Metodo de pago',16,'view_metodo_pago'),(65,'Can add Compra',17,'add_compras'),(66,'Can change Compra',17,'change_compras'),(67,'Can delete Compra',17,'delete_compras'),(68,'Can view Compra',17,'view_compras'),(69,'Can add Venta',18,'add_ventas'),(70,'Can change Venta',18,'change_ventas'),(71,'Can delete Venta',18,'delete_ventas'),(72,'Can view Venta',18,'view_ventas'),(73,'Can add detalle compra',19,'add_detallecompra'),(74,'Can change detalle compra',19,'change_detallecompra'),(75,'Can delete detalle compra',19,'delete_detallecompra'),(76,'Can view detalle compra',19,'view_detallecompra'),(77,'Can add detalle venta',20,'add_detalleventa'),(78,'Can change detalle venta',20,'change_detalleventa'),(79,'Can delete detalle venta',20,'delete_detalleventa'),(80,'Can view detalle venta',20,'view_detalleventa');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$870000$ynJnEaEooSw8LfbqEneLIz$0AHVyF2v/bFfE+CNfFSegL+6ihTUafa24BHypNm4tns=','2024-10-11 03:40:26.996716',1,'CRIS','','','fabiansarmientoglv@gmail.com',1,1,'2024-10-11 03:17:53.237016');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `apellido` varchar(150) NOT NULL,
  `nit` bigint unsigned NOT NULL,
  `correo_electronico` varchar(150) NOT NULL,
  `telefono` int unsigned NOT NULL,
  `Tipo_identificador_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nit` (`nit`),
  KEY `Cliente_Tipo_identificador_id_c98f0af8_fk_Tipo_identificador_id` (`Tipo_identificador_id`),
  CONSTRAINT `Cliente_Tipo_identificador_id_c98f0af8_fk_Tipo_identificador_id` FOREIGN KEY (`Tipo_identificador_id`) REFERENCES `tipo_identificador` (`id`),
  CONSTRAINT `cliente_chk_1` CHECK ((`nit` >= 0)),
  CONSTRAINT `cliente_chk_2` CHECK ((`telefono` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compra` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_compra` date NOT NULL,
  `metodo_pago_id` bigint NOT NULL,
  `proveedor_id` bigint NOT NULL,
  `finalizado` tinyint(1) DEFAULT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Compra_metodo_pago_id_7a20b5a3_fk_Metodo de pago_id` (`metodo_pago_id`),
  KEY `Compra_proveedor_id_b98cf6f8_fk_Proveedores_id` (`proveedor_id`),
  CONSTRAINT `Compra_metodo_pago_id_7a20b5a3_fk_Metodo de pago_id` FOREIGN KEY (`metodo_pago_id`) REFERENCES `metodo de pago` (`id`),
  CONSTRAINT `Compra_proveedor_id_b98cf6f8_fk_Proveedores_id` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(8,'apl','administradores'),(10,'apl','clientes'),(17,'apl','compras'),(19,'apl','detallecompra'),(20,'apl','detalleventa'),(11,'apl','marcas'),(16,'apl','metodo_pago'),(12,'apl','presentacion'),(15,'apl','productos'),(13,'apl','proveedores'),(7,'apl','tipo'),(9,'apl','tipo_identificador'),(14,'apl','unidad_medida'),(18,'apl','ventas'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2024-10-11 03:13:11.107177'),(2,'auth','0001_initial','2024-10-11 03:13:29.387290'),(3,'admin','0001_initial','2024-10-11 03:13:33.044002'),(4,'admin','0002_logentry_remove_auto_add','2024-10-11 03:13:33.216002'),(5,'admin','0003_logentry_add_action_flag_choices','2024-10-11 03:13:33.312328'),(6,'apl','0001_initial','2024-10-11 03:13:33.919815'),(7,'apl','0002_administradores_empleados_tipo_identificador_and_more','2024-10-11 03:13:37.762382'),(8,'apl','0003_marcas_presentacion_proveedores_unidad_medida','2024-10-11 03:13:39.940506'),(9,'apl','0004_unidad_medida_estado_alter_clientes_telefono_and_more','2024-10-11 03:13:54.933496'),(10,'apl','0005_proveedores_apellido_alter_proveedores_nit','2024-10-11 03:13:55.760494'),(11,'apl','0006_alter_proveedores_apellido','2024-10-11 03:13:55.869797'),(12,'apl','0007_alter_proveedores_apellido','2024-10-11 03:13:55.969750'),(13,'apl','0008_metodo_pago','2024-10-11 03:13:56.794495'),(14,'apl','0009_compras','2024-10-11 03:14:04.070441'),(15,'apl','0010_alter_compras_fecha_compra','2024-10-11 03:14:06.141874'),(16,'apl','0011_alter_compras_fecha_compra','2024-10-11 03:14:08.225594'),(17,'apl','0012_alter_compras_fecha_compra','2024-10-11 03:14:11.157481'),(18,'apl','0013_ventas','2024-10-11 03:14:21.054038'),(19,'apl','0014_alter_ventas_administrador','2024-10-11 03:14:23.733247'),(20,'apl','0015_alter_proveedores_options','2024-10-11 03:14:23.826859'),(21,'apl','0016_alter_proveedores_options','2024-10-11 03:14:23.931168'),(22,'apl','0017_alter_administradores_correo_electronico_and_more','2024-10-11 03:14:26.180587'),(23,'apl','0018_ventas_ventas_cantidad_ventas_ventas_unidad_medida','2024-10-11 03:14:30.992034'),(24,'apl','0019_rename_ventas_unidad_medida_ventas_ventas_unidad_medida','2024-10-11 03:14:35.806579'),(25,'apl','0020_ventas_ventas_precio','2024-10-11 03:14:38.821025'),(26,'apl','0021_remove_ventas_ventas_precio','2024-10-11 03:14:39.269642'),(27,'apl','0022_remove_ventas_ventas_unidad_medida','2024-10-11 03:14:42.016891'),(28,'apl','0023_alter_productos_precio','2024-10-11 03:14:44.476763'),(29,'apl','0018_alter_clientes_nit_alter_productos_nombre_and_more','2024-10-11 03:14:46.718301'),(30,'apl','0024_merge_20240723_1317','2024-10-11 03:14:46.775166'),(31,'apl','0025_remove_compras_producto_detallecompra','2024-10-11 03:14:52.077930'),(32,'apl','0024_merge_20240722_1308','2024-10-11 03:14:52.161772'),(33,'apl','0026_merge_20240725_1420','2024-10-11 03:14:52.255221'),(34,'apl','0027_detallecompra_compra','2024-10-11 03:14:54.175334'),(35,'apl','0026_merge_20240726_1340','2024-10-11 03:14:54.261977'),(36,'apl','0028_merge_20240727_2154','2024-10-11 03:14:54.373200'),(37,'apl','0029_detallecompra_cantidad','2024-10-11 03:14:56.033290'),(38,'apl','0030_remove_administradores_apellido_and_more','2024-10-11 03:15:08.614677'),(39,'apl','0028_merge_20240726_1440','2024-10-11 03:15:08.802284'),(40,'apl','0031_merge_20240730_2018','2024-10-11 03:15:08.892506'),(41,'apl','0032_remove_ventas_administrador_and_more','2024-10-11 03:15:11.014284'),(42,'apl','0033_clicktracking','2024-10-11 03:15:13.295856'),(43,'apl','0034_delete_clicktracking','2024-10-11 03:15:13.830339'),(44,'apl','0035_detallecompra_finalizado','2024-10-11 03:15:14.534436'),(45,'apl','0036_alter_productos_precio','2024-10-11 03:15:14.690583'),(46,'apl','0037_detalleventa','2024-10-11 03:15:18.861848'),(47,'apl','0038_remove_ventas_producto_remove_ventas_ventas_cantidad_and_more','2024-10-11 03:15:23.769526'),(48,'apl','0039_remove_detallecompra_finalizado_compras_finalizado_and_more','2024-10-11 03:15:29.008817'),(49,'apl','0040_alter_ventas_metodo_pago','2024-10-11 03:15:32.927263'),(50,'apl','0041_alter_compras_finalizado_and_more','2024-10-11 03:15:34.821297'),(51,'apl','0042_alter_administradores_numero_documento_and_more','2024-10-11 03:15:34.953607'),(52,'apl','0043_tipo_identificador_estado','2024-10-11 03:15:35.544484'),(53,'apl','0044_alter_clientes_tipo_identificador','2024-10-11 03:15:35.680717'),(54,'apl','0045_alter_tipo_identificador_estado','2024-10-11 03:15:35.777842'),(55,'apl','0043_remove_ventas_empleado_compras_usuario_and_more','2024-10-11 03:15:42.659492'),(56,'apl','0046_merge_20240905_1409','2024-10-11 03:15:42.878257'),(57,'apl','0047_alter_marcas_estado_alter_productos_marcas_and_more','2024-10-11 03:15:47.664390'),(58,'apl','0048_alter_clientes_correo_electronico_and_more','2024-10-11 03:15:47.839072'),(59,'apl','0049_detallecompra_precio_unitario_and_more','2024-10-11 03:16:00.888267'),(60,'apl','0050_alter_compras_usuario_alter_ventas_usuario','2024-10-11 03:16:04.033806'),(61,'apl','0051_alter_proveedores_nit','2024-10-11 03:16:04.112016'),(62,'apl','0052_alter_ventas_usuario','2024-10-11 03:16:05.915726'),(63,'apl','0053_alter_ventas_usuario','2024-10-11 03:16:07.334733'),(64,'apl','0054_alter_metodo_pago_nombre','2024-10-11 03:16:08.249565'),(65,'apl','0055_metodo_pago_estado_presentacion_estado_and_more','2024-10-11 03:16:10.102818'),(66,'apl','0056_alter_administradores_numero_documento_and_more','2024-10-11 03:16:10.223047'),(67,'apl','0057_proveedores_tipo_identicador_and_more','2024-10-11 03:16:11.685373'),(68,'apl','0058_alter_administradores_tipo_documento_and_more','2024-10-11 03:16:16.671857'),(69,'apl','0059_alter_administradores_tipo_documento','2024-10-11 03:16:20.826655'),(70,'apl','0060_alter_administradores_tipo_documento','2024-10-11 03:16:26.159867'),(71,'apl','0061_remove_administradores_tipo_documento_and_more','2024-10-11 03:16:29.246493'),(72,'apl','0062_remove_administradores_tipo_idetificacion_and_more','2024-10-11 03:16:31.611822'),(73,'apl','0063_alter_administradores_tipo_documento','2024-10-11 03:16:36.302575'),(74,'contenttypes','0002_remove_content_type_name','2024-10-11 03:16:38.778854'),(75,'auth','0002_alter_permission_name_max_length','2024-10-11 03:16:41.123412'),(76,'auth','0003_alter_user_email_max_length','2024-10-11 03:16:41.685059'),(77,'auth','0004_alter_user_username_opts','2024-10-11 03:16:41.933980'),(78,'auth','0005_alter_user_last_login_null','2024-10-11 03:16:44.251462'),(79,'auth','0006_require_contenttypes_0002','2024-10-11 03:16:44.376546'),(80,'auth','0007_alter_validators_add_error_messages','2024-10-11 03:16:44.921609'),(81,'auth','0008_alter_user_username_max_length','2024-10-11 03:16:48.485233'),(82,'auth','0009_alter_user_last_name_max_length','2024-10-11 03:16:55.633791'),(83,'auth','0010_alter_group_name_max_length','2024-10-11 03:16:56.332988'),(84,'auth','0011_update_proxy_permissions','2024-10-11 03:16:56.577677'),(85,'auth','0012_alter_user_first_name_max_length','2024-10-11 03:16:58.736195'),(86,'sessions','0001_initial','2024-10-11 03:16:59.929915');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('1q74zdwvbn8vvq1r8kq7ddew749o395l','.eJxVjEsOwiAUAO_C2hBKHwgu3XsG8j5UqoYmpV0Z725IutDtzGTeKuG-lbS3vKZZ1EUN6vTLCPmZaxfywHpfNC91W2fSPdGHbfq2SH5dj_ZvULCVvvXWWetJCB0GmMiIMcgZonCmSc44joHBos9AYMiAl8guxoFDCBzU5wv5njhZ:1sz6Ac:ozbSd0NaW4UxDzoBPjPGWabeO88Z1F1qnGFXQPfHr1w','2024-10-25 03:18:26.024536'),('52q1n8ecxqxhib4s6msr7he99a2kglg7','.eJxVjEsOwiAUAO_C2hBKHwgu3XsG8j5UqoYmpV0Z725IutDtzGTeKuG-lbS3vKZZ1EUN6vTLCPmZaxfywHpfNC91W2fSPdGHbfq2SH5dj_ZvULCVvvXWWetJCB0GmMiIMcgZonCmSc44joHBos9AYMiAl8guxoFDCBzU5wv5njhZ:1sz6Vv:rXT8u2vVDvqNNuX4jg4QMMDzYavE47uQdXeHsrOoHc0','2024-10-25 03:40:27.107953');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `edad` int unsigned NOT NULL,
  `cedula` bigint unsigned NOT NULL,
  `correo_electronico` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cedula` (`cedula`),
  CONSTRAINT `empleados_chk_1` CHECK ((`edad` >= 0)),
  CONSTRAINT `empleados_chk_2` CHECK ((`cedula` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marca`
--

DROP TABLE IF EXISTS `marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marca` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marca`
--

LOCK TABLES `marca` WRITE;
/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` VALUES (1,'Marca 1','Activo'),(2,'Marca 2','Activo');
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metodo de pago`
--

DROP TABLE IF EXISTS `metodo de pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metodo de pago` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Metodo de pago_nombre_56103617_uniq` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metodo de pago`
--

LOCK TABLES `metodo de pago` WRITE;
/*!40000 ALTER TABLE `metodo de pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `metodo de pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presentacion`
--

DROP TABLE IF EXISTS `presentacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presentacion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(150) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presentacion`
--

LOCK TABLES `presentacion` WRITE;
/*!40000 ALTER TABLE `presentacion` DISABLE KEYS */;
INSERT INTO `presentacion` VALUES (1,'Presentaciones 1','Activo'),(2,'Presentaciones 2','Activo');
/*!40000 ALTER TABLE `presentacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `cantidad` int unsigned NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `marcas_id` bigint NOT NULL,
  `presentacion_id` bigint NOT NULL,
  `tipo_id` bigint NOT NULL,
  `unidad_medida_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Producto_marcas_id_84b6b146_fk_Marca_id` (`marcas_id`),
  KEY `Producto_presentacion_id_abd188df_fk_Presentacion_id` (`presentacion_id`),
  KEY `Producto_tipo_id_477475b4_fk_Tipo_id` (`tipo_id`),
  KEY `Producto_unidad_medida_id_493a22e2_fk_Unidad_Medida_id` (`unidad_medida_id`),
  CONSTRAINT `Producto_marcas_id_84b6b146_fk_Marca_id` FOREIGN KEY (`marcas_id`) REFERENCES `marca` (`id`),
  CONSTRAINT `Producto_presentacion_id_abd188df_fk_Presentacion_id` FOREIGN KEY (`presentacion_id`) REFERENCES `presentacion` (`id`),
  CONSTRAINT `Producto_tipo_id_477475b4_fk_Tipo_id` FOREIGN KEY (`tipo_id`) REFERENCES `tipo` (`id`),
  CONSTRAINT `Producto_unidad_medida_id_493a22e2_fk_Unidad_Medida_id` FOREIGN KEY (`unidad_medida_id`) REFERENCES `unidad_medida` (`id`),
  CONSTRAINT `producto_chk_1` CHECK ((`cantidad` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,'Producto 1',12,2000.00,1,1,1,1),(2,'producto 2',21,1000.00,1,1,1,1),(3,'Producto 3',21,122.00,2,2,1,2);
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `nit` varchar(20) NOT NULL,
  `ubicacion` varchar(255) NOT NULL,
  `telefono` int unsigned NOT NULL,
  `correo_electronico` varchar(100) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `tipo_identicador_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nit` (`nit`),
  KEY `Proveedores_tipo_identicador_id_3688989e_fk_Tipo_iden` (`tipo_identicador_id`),
  CONSTRAINT `Proveedores_tipo_identicador_id_3688989e_fk_Tipo_iden` FOREIGN KEY (`tipo_identicador_id`) REFERENCES `tipo_identificador` (`id`),
  CONSTRAINT `Proveedores_telefono_ae938b67_check` CHECK ((`telefono` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo`
--

DROP TABLE IF EXISTS `tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) DEFAULT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Tipo_nombre_f386ac74_uniq` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo`
--

LOCK TABLES `tipo` WRITE;
/*!40000 ALTER TABLE `tipo` DISABLE KEYS */;
INSERT INTO `tipo` VALUES (1,'tipo 2','Activo');
/*!40000 ALTER TABLE `tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_identificador`
--

DROP TABLE IF EXISTS `tipo_identificador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_identificador` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_identificador`
--

LOCK TABLES `tipo_identificador` WRITE;
/*!40000 ALTER TABLE `tipo_identificador` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipo_identificador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unidad_medida`
--

DROP TABLE IF EXISTS `unidad_medida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidad_medida` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `estado` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unidad_medida`
--

LOCK TABLES `unidad_medida` WRITE;
/*!40000 ALTER TABLE `unidad_medida` DISABLE KEYS */;
INSERT INTO `unidad_medida` VALUES (1,'Unidades de medida 1','Activo'),(2,'Unidades de medida 2','Activo');
/*!40000 ALTER TABLE `unidad_medida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime(6) NOT NULL,
  `cliente_id` bigint NOT NULL,
  `metodo_pago_id` bigint DEFAULT NULL,
  `finalizado` tinyint(1) NOT NULL,
  `usuario` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Venta_cliente_id_a2b0be2d_fk_Cliente_id` (`cliente_id`),
  KEY `Venta_metodo_pago_id_8a17bfb8_fk_Metodo de pago_id` (`metodo_pago_id`),
  CONSTRAINT `Venta_cliente_id_a2b0be2d_fk_Cliente_id` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`),
  CONSTRAINT `Venta_metodo_pago_id_8a17bfb8_fk_Metodo de pago_id` FOREIGN KEY (`metodo_pago_id`) REFERENCES `metodo de pago` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 22:59:33
